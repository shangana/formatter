﻿Thank you for using WisdomTool Formatter.

Your donation is appreciated and will ensure future development of REST Client.

Donations will help towards hardware, software, hosting and other costs.

When you complete the donation, please send email to contact the author, then you will receive an password to decompress the zip file.   

Thank you for your support ♥

***************************************************
Donation link: https://www.paypal.me/codespring/10

Email:   maspring@126.com
Author:  Yu Dong Wang (Dom Wang)
Website: www.maspring.com
***************************************************
