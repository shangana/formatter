﻿WisdomTool Formatter源代码是在作者辛勤的付出下所完成的工具。

虽然在国内已经习惯了下载免费代码，使用免费工具，但是还是要给予这些默默无闻的程序猿们一点点爱心和回报，请理解他们，请尊重他们的辛勤付出！

索取工具解压码，请先通过QQ或者Email联系作者，沟通好后，打开支付宝或者微信扫一扫二维码文件：maspring-alipay.png, maspring-weixin.png，完成支付。

作者会确认同时会在QQ或者邮件里发给您解压码。

谢谢您对WisdomTool Formatter工具的支持与厚爱！

*****************************************
QQ：      2353941272
Email:   maspring@126.com
Author:  Yu Dong Wang (Dom Wang)
Website: www.maspring.com
*****************************************